// Mock data for RiskMind prototype

window.PLUGINS = [
  // Business plugins
  { id: 'ccar', name: 'CCAR IMS', kind: 'business', status: 'connected', desc: 'CCAR Internal Model Specification' },
  { id: 'fxo', name: 'FXO Stress Explain', kind: 'business', status: 'connected', desc: 'FX Options stress decomposition' },
  { id: 'gsp', name: 'GSP Stress Explain', kind: 'business', status: 'connected', desc: 'Global Stress P&L breakdown' },
  { id: 'var', name: 'VaR Backtest', kind: 'business', status: 'connected', desc: 'Backtesting suite' },
  { id: 'mra', name: 'Market Risk Archive', kind: 'business', status: 'connected', desc: 'Historical risk submissions' },
  { id: 'limit', name: 'Limit Monitor', kind: 'business', status: 'not-connected', desc: 'Position limit framework' },
  { id: 'fed', name: 'FRB 14Q Report', kind: 'business', status: 'not-connected', desc: 'Regulatory reporting' },
  // Special-purpose subagents
  { id: 'viz', name: 'Data Visualizer', kind: 'special', status: 'connected', desc: 'Charts, dashboards, reports' },
  { id: 'sql', name: 'SQL Analyst', kind: 'special', status: 'connected', desc: 'Query risk warehouse' },
  { id: 'pyq', name: 'PyQuant', kind: 'special', status: 'connected', desc: 'Python quant calcs' },
  { id: 'doc', name: 'Doc Composer', kind: 'special', status: 'not-connected', desc: 'Memos, narratives' },
  { id: 'web', name: 'Market News', kind: 'special', status: 'not-connected', desc: 'External news + macro' },
];

window.HISTORY = [
  { id: 'h1', title: 'Intraday VaR breach — JPY desk', when: 'Today, 09:42', preview: 'Why did the JPY rates desk breach 1d VaR at the open?', tags: ['VaR'], active: true },
  { id: 'h2', title: 'CCAR Q1 2026 submission readiness', when: 'Yesterday, 17:08', preview: 'Run readiness check on all CCAR IMS modules…', tags: ['CCAR'] },
  { id: 'h3', title: 'FXO vega hot-spots — EM bucket', when: 'May 8, 14:21', preview: 'Decompose the FXO vega P&L for the EMEA EM book…', tags: ['FXO'] },
  { id: 'h4', title: 'GSP stress — Rates Up 200bps explain', when: 'May 7, 11:03', preview: 'Walk me through the largest contributors to the Rates Up 200…', tags: ['GSP', 'Stress'] },
  { id: 'h5', title: 'Backtest exception — 5d window', when: 'May 6, 16:45', preview: 'Investigate the May-2 backtest exception on the credit book.', tags: ['Backtest'] },
  { id: 'h6', title: 'Sensitivity drift — EUR swaptions', when: 'May 5, 10:11', preview: 'Compare gamma exposure week-over-week on EUR swaptions.', tags: ['Sensitivities'] },
  { id: 'h7', title: 'Limit utilization briefing', when: 'May 2, 08:30', preview: 'Give me the limit utilization snapshot for the morning brief.', tags: ['Limits'] },
];

window.FILES = [
  { id: 'f1', name: 'eod_positions_2026-05-10.parquet', size: '142.8 MB', when: '14 min ago', kind: 'PARQ', tags: ['positions', 'EOD'] },
  { id: 'f2', name: 'fx_vol_surface_jpy.csv', size: '3.4 MB', when: '1 hr ago', kind: 'CSV', tags: ['vol', 'FXO'] },
  { id: 'f3', name: 'CCAR_IMS_scenarios_Q1.xlsx', size: '512 KB', when: '2 hr ago', kind: 'XLSX', tags: ['CCAR', 'scenarios'] },
  { id: 'f4', name: 'desk_pnl_journal_2026-05-10.json', size: '88 KB', when: 'Today', kind: 'JSON', tags: ['P&L'] },
  { id: 'f5', name: 'limits_master.yml', size: '24 KB', when: 'May 9', kind: 'YML', tags: ['limits'] },
];

window.PRELOADED_CHAT = [
  { role: 'user', content: 'Intraday VaR on the JPY rates desk just breached its 1-day limit. Pull the contributors, compare against yesterday\'s snapshot, and build me a dashboard.' },
  { role: 'assistant', content: 'On it. I\'ll pull EOD positions, the JPY desk\'s 1d VaR decomposition from the risk warehouse, and reconstruct yesterday\'s baseline for comparison. Then I\'ll have the visualizer assemble a dashboard with the top contributors and a sensitivity walk.', tools: [
    { kind: 'skill', name: 'Skill', arg: 'risk_warehouse.pull_var_snapshot', res: '2 snapshots · 1,284 positions' },
    { kind: 'read', name: 'Read', arg: 'eod_positions_2026-05-10.parquet', res: '142.8 MB · 1,284 rows' },
    { kind: 'subagent', name: 'SQL Analyst', arg: 'select sensi_grid where desk=\'JPY_RATES\'', res: '3,420 rows · 88 buckets' },
    { kind: 'skill', name: 'Skill', arg: 'fxo.stress_explain --desk JPY_RATES --tenor 2y,5y,10y,30y', res: '4 buckets explained' },
    { kind: 'bash', cmd: 'python -m riskmind.var_walk --from 2026-05-09 --to 2026-05-10 --desk JPY_RATES', out: [
      { t: 'out', s: '[riskmind] loading snapshots…' },
      { t: 'out', s: '[riskmind] aligning sensitivity buckets (88)' },
      { t: 'out', s: '[riskmind] computing P&L attribution…' },
      { t: 'out', s: 'Δ VaR (1d, 99%): +$3.2M  →  $14.7M (limit $12.0M)  BREACH' },
      { t: 'out', s: 'Top drivers:  10y JPY swap rate (+$1.8M), 30y basis (+$0.7M), JGB futures basis (+$0.4M)' },
      { t: 'out', s: 'done in 4.21s' },
    ] },
    { kind: 'subagent', name: 'Data Visualizer', arg: 'render dashboard "JPY Rates VaR Breach"', res: 'artifact ready' },
  ], artifact: { id: 'jpy_breach', name: 'JPY Rates VaR Breach.html' } },
];

window.DEFAULT_DASHBOARD_JSON = {
  title: 'JPY Rates VaR Breach',
  subtitle: 'Intraday breach investigation · desk JPY_RATES · as of 2026-05-11 09:42 JST',
  status: { label: 'LIVE', tone: 'warn' },
  meta: [
    { label: 'Desk', value: 'JPY Rates' },
    { label: 'Snapshot', value: '2026-05-11 09:42' },
    { label: 'Confidence', value: '99% / 1d' },
  ],
  kpis: [
    { label: '1d VaR', value: '$14.7M', delta: '+$3.2M', dir: 'up', sub: 'vs $11.5M yday' },
    { label: 'Limit', value: '$12.0M', delta: '122% util', dir: 'up', sub: 'BREACH' },
    { label: 'Stress P&L (worst)', value: '-$48.3M', delta: '+12%', dir: 'up', sub: 'Rates Up 200' },
    { label: 'Backtest exceptions (1y)', value: '4', delta: '+1', dir: 'up', sub: 'within green zone' },
  ],
  insights: [
    { anchor: 'after-kpis', label: 'Why this matters', body: 'The desk crossed its 1d VaR limit by **$2.7M (22%)** overnight. ~58% of the move is attributable to a steeper 10y–30y JPY swap curve following the BoJ press conference, with the remainder driven by a wider JGB futures basis. Position sizing did **not** materially change — this is a market-driven breach.' },
    { anchor: 'after-walk', label: 'Decomposition read', body: 'The walk shows **rates delta** dominating (+$2.1M), while vega and basis each add ~$0.5M. The desk holds ~80% of risk in the 5y–10y bucket; that bucket alone explains $1.8M of the breach.' },
    { anchor: 'after-table', label: 'Recommended action', body: 'Three options to bring VaR back within limit by EOD: (1) trim 10y receiver swaps by ~¥85B notional, (2) hedge with 30y payer wedge, (3) request a one-day temporary limit increase to $15M pending close. The Limits team auto-flags this at 17:00 JST.' },
  ],
  walk: {
    title: 'VaR walk · yesterday → today',
    sub: 'P&L attribution, $M',
    series: [
      { label: 'VaR T-1', value: 11.5, kind: 'base' },
      { label: '10y JPY rate', value: 1.8, kind: 'pos' },
      { label: '30y basis', value: 0.7, kind: 'pos' },
      { label: 'JGB futures', value: 0.4, kind: 'pos' },
      { label: 'Vega', value: 0.5, kind: 'pos' },
      { label: 'Cross-gamma', value: -0.2, kind: 'neg' },
      { label: 'VaR T', value: 14.7, kind: 'base' },
    ],
  },
  histo: {
    title: 'P&L distribution · 250d historical sim',
    sub: 'Simulated 1d P&L, $M',
    bins: [2,3,5,8,14,22,38,52,46,28,18,9,4,2,1],
    var99: -14.7,
    es99: -18.2,
  },
  contributors: {
    title: 'Top risk factor contributors',
    sub: 'Marginal VaR · $M',
    rows: [
      { factor: '10y JPY swap rate', value: 1.83, pct: 57 },
      { factor: '30y JPY/USD basis', value: 0.71, pct: 28 },
      { factor: 'JGB futures basis', value: 0.42, pct: 17 },
      { factor: 'USDJPY 1m vol', value: 0.31, pct: 12 },
      { factor: '5y JPY swap rate', value: 0.18, pct: 8 },
      { factor: 'CSA discount curve', value: -0.12, pct: -5 },
    ],
  },
};

window.SLASH_COMMANDS = [
  { cmd: '/stress-pnl', desc: 'Generate a stress P&L explain report' },
  { cmd: '/var-breach', desc: 'Investigate the latest VaR breach' },
  { cmd: '/ccar-status', desc: 'Check CCAR submission readiness' },
  { cmd: '/limit-util', desc: 'Limit utilization snapshot' },
  { cmd: '/backtest', desc: 'Run VaR backtest exceptions' },
  { cmd: '/upload', desc: 'Attach a file from your machine' },
  { cmd: '/plugin', desc: 'Connect or disconnect a plugin' },
  { cmd: '/export', desc: 'Export current artifact as PDF/HTML' },
];

// Templates for new-dashboard generation from user query
window.NEW_DASHBOARD_TEMPLATE = (topic) => ({
  title: topic,
  subtitle: `Generated by RiskMind · ${new Date().toISOString().slice(0,16).replace('T',' ')}`,
  status: { label: 'DRAFT', tone: 'ok' },
  meta: [
    { label: 'Source', value: 'Risk Warehouse' },
    { label: 'Window', value: 'T-30d' },
    { label: 'Method', value: 'HistSim' },
  ],
  kpis: [
    { label: 'Exposure', value: '$842M', delta: '+3.1%', dir: 'up', sub: 'gross notional' },
    { label: '1d VaR', value: '$9.3M', delta: '-0.4M', dir: 'dn', sub: '99% conf.' },
    { label: 'Worst stress', value: '-$32.1M', delta: '+5%', dir: 'up', sub: 'Credit Widen' },
    { label: 'Positions', value: '648', delta: '+12', dir: 'up', sub: 'in scope' },
  ],
  insights: [
    { anchor: 'after-kpis', label: 'Summary', body: `Auto-generated overview for **${topic}**. Edit the JSON in the middle panel and hit **Render** to update this view live.` },
  ],
  walk: {
    title: 'Exposure walk',
    sub: '$M',
    series: [
      { label: 'T-30', value: 818, kind: 'base' },
      { label: 'New trades', value: 38, kind: 'pos' },
      { label: 'Roll-off', value: -14, kind: 'neg' },
      { label: 'Re-marks', value: 0, kind: 'pos' },
      { label: 'T', value: 842, kind: 'base' },
    ],
  },
  histo: { title: 'P&L distribution', sub: 'sim 1d P&L, $M', bins: [3,5,9,18,30,42,38,24,12,6,2], var99: -9.3, es99: -12.1 },
  contributors: {
    title: 'Top contributors',
    sub: 'Marginal VaR',
    rows: [
      { factor: 'Factor A', value: 1.2, pct: 38 },
      { factor: 'Factor B', value: 0.9, pct: 28 },
      { factor: 'Factor C', value: 0.6, pct: 19 },
      { factor: 'Factor D', value: 0.3, pct: 9 },
    ],
  },
});
