// Left panel: Chat, History, Files

const CC_GLYPHS = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'];
const CC_VERBS = ['Thinking', 'Pondering', 'Cogitating', 'Reasoning', 'Analyzing', 'Investigating', 'Computing'];

const CCSpinner = ({ verb }) => {
  const [g, setG] = React.useState(0);
  const [v, setV] = React.useState(verb || CC_VERBS[Math.floor(Math.random() * CC_VERBS.length)]);
  const [secs, setSecs] = React.useState(0);
  React.useEffect(() => {
    const t1 = setInterval(() => setG(x => (x + 1) % CC_GLYPHS.length), 90);
    const t2 = setInterval(() => setSecs(s => s + 1), 1000);
    const t3 = verb ? null : setInterval(() => setV(CC_VERBS[Math.floor(Math.random() * CC_VERBS.length)]), 4200);
    return () => { clearInterval(t1); clearInterval(t2); if (t3) clearInterval(t3); };
  }, [verb]);
  return (
    <div className="cc-spinner">
      <span className="glyph" style={{ animation: 'none' }}>{CC_GLYPHS[g]}</span>
      <span className="label">{v}…</span>
      <span className="hint">({secs}s · esc to interrupt)</span>
    </div>
  );
};

const LeftPanel = ({ mode, onToggleMiddle, middleOpen, chat, onSendMessage, isAssistantTyping, onLoadHistory, activeHistoryId, onNewChat }) => {
  return (
    <>
      <div className="panel-head">
        <button className="icon-btn" title={middleOpen ? 'Hide middle panel' : 'Show middle panel'} onClick={onToggleMiddle}>
          <Icon name={middleOpen ? 'panel-open' : 'panel'} size={16}/>
        </button>
        <div className="title">
          {mode === 'chat' && (chat.title || 'New chat')}
          {mode === 'history' && 'Chat history'}
          {mode === 'files' && 'Files'}
        </div>
        {mode === 'chat' ? <button className="icon-btn" title="New chat" onClick={onNewChat}><Icon name="plus" size={16}/></button> : null}
      </div>
      {mode === 'chat' && <ChatView chat={chat} onSendMessage={onSendMessage} isAssistantTyping={isAssistantTyping}/>}
      {mode === 'history' && <HistoryView activeId={activeHistoryId} onLoad={onLoadHistory}/>}
      {mode === 'files' && <FilesView/>}
    </>
  );
};

const ChatView = ({ chat, onSendMessage, isAssistantTyping }) => {
  const scrollRef = React.useRef(null);
  const [text, setText] = React.useState('');
  const [showSlash, setShowSlash] = React.useState(false);
  const [slashIdx, setSlashIdx] = React.useState(0);
  const taRef = React.useRef(null);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [chat.messages, isAssistantTyping]);

  const filteredSlash = React.useMemo(() => {
    if (!text.startsWith('/')) return [];
    const q = text.slice(1).toLowerCase();
    return window.SLASH_COMMANDS.filter(c => c.cmd.slice(1).toLowerCase().startsWith(q));
  }, [text]);

  React.useEffect(() => {
    setShowSlash(text.startsWith('/') && filteredSlash.length > 0);
    setSlashIdx(0);
  }, [text, filteredSlash.length]);

  const handleKey = (e) => {
    if (showSlash) {
      if (e.key === 'ArrowDown') { e.preventDefault(); setSlashIdx(i => Math.min(filteredSlash.length-1, i+1)); return; }
      if (e.key === 'ArrowUp') { e.preventDefault(); setSlashIdx(i => Math.max(0, i-1)); return; }
      if (e.key === 'Tab' || e.key === 'Enter') {
        e.preventDefault();
        const c = filteredSlash[slashIdx];
        if (c) setText(c.cmd + ' ');
        setShowSlash(false);
        return;
      }
      if (e.key === 'Escape') { setShowSlash(false); return; }
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };
  const submit = () => {
    const v = text.trim();
    if (!v || isAssistantTyping) return;
    onSendMessage(v);
    setText('');
  };

  return (
    <>
      <div className="chat-scroll" ref={scrollRef}>
        {chat.messages.map((m, i) => <Message key={i} msg={m} isLast={i === chat.messages.length - 1 && isAssistantTyping}/>)}
        {isAssistantTyping && (chat.messages.length === 0 || chat.messages[chat.messages.length-1].role === 'user') ? (
          <div className="msg assistant"><div className="who">RiskMind</div><CCSpinner/></div>
        ) : null}
        <div style={{ height: 6 }}></div>
      </div>
      <div className="composer">
        <div className="composer-box" style={{ position: 'relative' }}>
          {showSlash ? (
            <div className="slash-menu">
              {filteredSlash.map((c, i) => (
                <div key={c.cmd} className={`slash-item ${i === slashIdx ? 'active' : ''}`} onMouseEnter={() => setSlashIdx(i)} onClick={() => { setText(c.cmd + ' '); setShowSlash(false); taRef.current?.focus(); }}>
                  <span className="cmd">{c.cmd}</span>
                  <span className="desc">{c.desc}</span>
                </div>
              ))}
            </div>
          ) : null}
          <textarea ref={taRef} placeholder="Ask anything · type / for commands" value={text} onChange={e => setText(e.target.value)} onKeyDown={handleKey} rows={1} style={{ height: Math.min(120, Math.max(22, text.split('\n').length * 18 + 4)) }}/>
          <div className="composer-row">
            <button className="icon-btn" title="Attach file"><Icon name="attach" size={15}/></button>
            <button className="icon-btn" title="Slash commands" onClick={() => { setText('/'); taRef.current?.focus(); }}><Icon name="code" size={15}/></button>
            <div className="spacer"></div>
            <span style={{ fontSize: 11, color: 'var(--text-3)' }}>{isAssistantTyping ? 'agent running…' : '⌘+Enter to send'}</span>
            <button className="send-btn" onClick={submit} disabled={!text.trim() || isAssistantTyping} title="Send"><Icon name="send" size={14}/></button>
          </div>
        </div>
      </div>
    </>
  );
};

const Message = ({ msg, isLast }) => {
  if (msg.role === 'user') {
    return (
      <div className="msg user">
        <div className="who">You</div>
        <div className="bubble">{msg.content}</div>
      </div>
    );
  }
  // assistant
  return (
    <div className="msg assistant">
      <div className="who">RiskMind</div>
      {msg.tools && msg.tools.length > 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {msg.tools.slice(0, 6).map((t, i) => (
            <div key={i} className={`tool-stub ${t.kind}`}>
              <span className="name">{t.kind === 'bash' ? 'Bash' : t.name}</span>
              <span style={{ color: 'var(--text-3)' }}>(</span>
              <span className="arg">{(t.arg || t.cmd || '').slice(0, 64)}{(t.arg || t.cmd || '').length > 64 ? '…' : ''}</span>
              <span style={{ color: 'var(--text-3)' }}>)</span>
            </div>
          ))}
          {msg.tools.length > 6 ? <div style={{ fontSize: 11, color: 'var(--text-3)' }}>+{msg.tools.length - 6} more steps</div> : null}
        </div>
      ) : null}
      <div className="bubble" dangerouslySetInnerHTML={{ __html: (msg.streamed || msg.content || '').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/`(.+?)`/g, '<code>$1</code>') + (isLast && msg.streamed && msg.streamed.length < (msg.content || '').length ? '<span class="caret"></span>' : '') }}></div>
      {msg.artifact ? (
        <div className="artifact-card" onClick={() => window.dispatchEvent(new CustomEvent('riskmind:open-artifact', { detail: msg.artifact.id }))}>
          <div className="preview"><Icon name="spark" size={22}/></div>
          <div className="meta">
            <div className="t">{msg.artifact.name}</div>
            <div className="s">Interactive dashboard · click to open</div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

const HistoryView = ({ activeId, onLoad }) => {
  const [q, setQ] = React.useState('');
  const filtered = window.HISTORY.filter(h => !q || (h.title + h.preview).toLowerCase().includes(q.toLowerCase()));
  const groups = [
    { l: 'Today', items: filtered.filter(h => h.when.startsWith('Today')) },
    { l: 'Yesterday', items: filtered.filter(h => h.when.startsWith('Yesterday')) },
    { l: 'Earlier', items: filtered.filter(h => !h.when.startsWith('Today') && !h.when.startsWith('Yesterday')) },
  ];
  return (
    <>
      <div style={{ padding: '8px 10px 4px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, border: '1px solid var(--border)', borderRadius: 8, padding: '6px 8px', background: 'var(--panel-2)' }}>
          <Icon name="search" size={13} stroke={1.8}/>
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search chats…" style={{ flex: 1, fontSize: 12 }}/>
        </div>
      </div>
      <div className="history-list">
        {groups.map(g => g.items.length === 0 ? null : (
          <div key={g.l}>
            <div className="section-label">{g.l}</div>
            {g.items.map(h => (
              <div key={h.id} className={`history-item ${h.id === activeId ? 'active' : ''}`} onClick={() => onLoad(h.id)}>
                <div className="t">{h.title}</div>
                <div className="s">
                  <span>{h.when}</span>
                  <span style={{ display: 'flex', gap: 4 }}>{h.tags.map(t => <span key={t} className="badge">{t}</span>)}</span>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
};

const FilesView = () => {
  return (
    <>
      <div className="upload-zone">
        <div style={{ marginBottom: 6 }}><Icon name="upload" size={20}/></div>
        <div className="big">Drop files to upload</div>
        <div>parquet · csv · json · xlsx · yml</div>
      </div>
      <div className="files-list">
        <div className="section-label">In this session</div>
        {window.FILES.map(f => (
          <div key={f.id} className="file-card">
            <div className="file-icon">{f.kind}</div>
            <div className="meta">
              <div className="t">{f.name}</div>
              <div className="s">{f.size} · {f.when}</div>
              <div className="tags">{f.tags.map(t => <span key={t} className="tag">{t}</span>)}</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

window.LeftPanel = LeftPanel;
