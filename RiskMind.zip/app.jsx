// Root app — state, orchestration, sim
const { useState, useEffect, useRef, useCallback, useMemo } = React;

function App() {
  const [theme, setTheme] = useState('light');
  useEffect(() => { document.documentElement.setAttribute('data-theme', theme); }, [theme]);
  const streaming = true;

  // ──── Panels ────
  const [leftMode, setLeftMode] = useState('chat'); // chat | history | files
  const [middleOpen, setMiddleOpen] = useState(false);
  const [middleTab, setMiddleTab] = useState('agent');

  const [leftWidth, setLeftWidth] = useState(340);
  const [middleWidth, setMiddleWidth] = useState(440);
  // Resize state
  const startResize = (which) => (e) => {
    e.preventDefault();
    const startX = e.clientX;
    const startLeft = leftWidth;
    const startMid = middleWidth;
    const onMove = (ev) => {
      const dx = ev.clientX - startX;
      if (which === 'left') setLeftWidth(Math.max(260, Math.min(560, startLeft + dx)));
      if (which === 'middle') setMiddleWidth(Math.max(320, Math.min(800, startMid + dx)));
    };
    const onUp = () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); document.body.style.cursor = ''; };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    document.body.style.cursor = 'col-resize';
  };

  // ──── Plugins ────
  const [plugins, setPlugins] = useState(window.PLUGINS);
  const togglePlugin = (id) => {
    setPlugins(prev => prev.map(p => {
      if (p.id !== id) return p;
      if (p.status === 'connected') return { ...p, status: 'not-connected' };
      if (p.status === 'not-connected') return { ...p, status: 'loading' };
      return p;
    }));
    // simulate loading→connected
    setTimeout(() => {
      setPlugins(prev => prev.map(p => p.id === id && p.status === 'loading' ? { ...p, status: 'connected' } : p));
    }, 900 + Math.random() * 600);
  };

  // ──── Chat ────
  const [chat, setChat] = useState({ id: 'h1', title: 'Intraday VaR breach — JPY desk', messages: [] });
  const [isAssistantTyping, setIsAssistantTyping] = useState(false);
  const [agentLog, setAgentLog] = useState([]);
  const [isAgentRunning, setIsAgentRunning] = useState(false);

  // ──── Artifacts ────
  const [artifacts, setArtifacts] = useState([
    { id: 'jpy_breach', name: 'JPY Rates VaR Breach.html', spec: window.DEFAULT_DASHBOARD_JSON },
  ]);
  const [activeArtifactId, setActiveArtifactId] = useState('jpy_breach');

  // JSON editor mirrors selected artifact
  const [jsonText, setJsonText] = useState(JSON.stringify(window.DEFAULT_DASHBOARD_JSON, null, 2));
  const [jsonDirty, setJsonDirty] = useState(false);
  const [jsonError, setJsonError] = useState(null);
  // when active artifact changes, reload editor
  useEffect(() => {
    const a = artifacts.find(x => x.id === activeArtifactId);
    if (!a) return;
    if (a.type === 'html') {
      setJsonText(a.html || '');
      setJsonDirty(false);
      setJsonError(null);
    } else if (a.spec) {
      setJsonText(JSON.stringify(a.spec, null, 2));
      setJsonDirty(false);
      setJsonError(null);
    }
  }, [activeArtifactId]);
  // validate live (JSON only)
  useEffect(() => {
    const a = artifacts.find(x => x.id === activeArtifactId);
    if (!a) return;
    if (a.type === 'html') {
      setJsonError(null);
      setJsonDirty((a.html || '') !== jsonText);
      return;
    }
    try { JSON.parse(jsonText); setJsonError(null); }
    catch (e) { setJsonError(e.message.replace(/^JSON\.parse:?\s*/i, '')); }
    if (a.spec && JSON.stringify(a.spec, null, 2) !== jsonText) setJsonDirty(true);
    else setJsonDirty(false);
  }, [jsonText, activeArtifactId, artifacts]);

  const handleRender = () => {
    const a = artifacts.find(x => x.id === activeArtifactId);
    if (!a) return;
    if (a.type === 'html') {
      setArtifacts(prev => prev.map(x => x.id === activeArtifactId ? { ...x, html: jsonText, renderKey: (x.renderKey || 0) + 1 } : x));
      setJsonDirty(false);
      return;
    }
    try {
      const parsed = JSON.parse(jsonText);
      setArtifacts(prev => prev.map(x => x.id === activeArtifactId ? { ...x, spec: parsed } : x));
      setJsonDirty(false);
    } catch (e) { /* button disabled when invalid */ }
  };

  const onNewArtifact = () => {
    const id = 'html_' + Math.random().toString(36).slice(2, 8);
    const starter = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, sans-serif; padding: 40px; color: #0a0a0a; }
    h1 { font-size: 24px; letter-spacing: -0.02em; margin: 0 0 6px; }
    .sub { color: #6b7280; font-size: 13px; margin-bottom: 24px; }
    .card { border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; max-width: 560px; }
    .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f1f1f3; font-variant-numeric: tabular-nums; }
    .row:last-child { border-bottom: none; }
  </style>
</head>
<body>
  <h1>My Custom Artifact</h1>
  <div class="sub">Edit the HTML in the middle panel, hit Render.</div>
  <div class="card">
    <div class="row"><span>1d VaR</span><b>$14.7M</b></div>
    <div class="row"><span>Limit</span><b>$12.0M</b></div>
    <div class="row"><span>Utilization</span><b>122%</b></div>
  </div>
</body>
</html>`;
    setArtifacts(a => [...a, { id, name: 'Untitled.html', type: 'html', html: starter, renderKey: 0 }]);
    setActiveArtifactId(id);
    setMiddleOpen(true);
    setMiddleTab('editor');
  };

  // ──── Preload chat: stream the canned response ────
  const preloadedRef = useRef(false);
  useEffect(() => {
    if (preloadedRef.current) return;
    preloadedRef.current = true;
    playScript(window.PRELOADED_CHAT);
  }, []);

  const ts = () => nowTs();

  // Drive a scripted turn: user msg already in chat; sim agent activity + assistant response
  const playScript = async (script) => {
    for (const step of script) {
      if (step.role === 'user') {
        setChat(c => ({ ...c, messages: [...c.messages, { role: 'user', content: step.content }] }));
        await sleep(450);
      } else if (step.role === 'assistant') {
        // begin agent run
        setIsAgentRunning(true);
        setIsAssistantTyping(true);
        if (!middleOpen) {
          // keep closed by default; user opens via toggle
        }
        // stream tool log entries
        for (const t of (step.tools || [])) {
          await sleep(420 + Math.random() * 280);
          if (t.kind === 'bash') {
            const entry = { kind: 'bash', cmd: t.cmd, ts: ts(), label: 'subprocess', lines: [] };
            setAgentLog(l => [...l, entry]);
            // stream bash output lines
            for (const ln of (t.out || [])) {
              await sleep(180 + Math.random() * 140);
              setAgentLog(l => {
                const copy = l.slice();
                const last = copy[copy.length - 1];
                if (last && last.kind === 'bash') {
                  copy[copy.length - 1] = { ...last, lines: [...last.lines, ln] };
                }
                return copy;
              });
            }
          } else {
            setAgentLog(l => [...l, { ...t, ts: ts() }]);
          }
        }
        await sleep(300);
        // stream assistant text
        const full = step.content;
        const useStream = streaming;
        const placeholder = { role: 'assistant', content: full, streamed: useStream ? '' : full, tools: step.tools || [], artifact: null };
        setChat(c => ({ ...c, messages: [...c.messages, placeholder] }));
        if (useStream) {
          for (let i = 1; i <= full.length; i++) {
            const sub = full.slice(0, i);
            setChat(c => {
              const ms = c.messages.slice();
              ms[ms.length - 1] = { ...ms[ms.length - 1], streamed: sub };
              return c.messages[c.messages.length - 1] === ms[ms.length - 1] ? c : { ...c, messages: ms };
            });
            // chunk speed: ~8 chars per frame, ~30ms per chunk
            const chunk = 6 + Math.floor(Math.random() * 6);
            i += chunk - 1;
            await sleep(22);
          }
          // ensure final
          setChat(c => {
            const ms = c.messages.slice();
            ms[ms.length - 1] = { ...ms[ms.length - 1], streamed: full };
            return { ...c, messages: ms };
          });
        }
        // attach artifact
        if (step.artifact) {
          setChat(c => {
            const ms = c.messages.slice();
            ms[ms.length - 1] = { ...ms[ms.length - 1], artifact: step.artifact };
            return { ...c, messages: ms };
          });
        }
        setIsAssistantTyping(false);
        setIsAgentRunning(false);
      }
    }
  };

  // ──── Free-form user send → simulated agent response ────
  const onSendMessage = async (text) => {
    setChat(c => ({ ...c, messages: [...c.messages, { role: 'user', content: text }] }));
    // figure out scenario
    const lowered = text.toLowerCase();
    const isSlash = text.startsWith('/');
    const wantsDashboard = isSlash || /dashboard|report|chart|visual|show|build|generate|stress|breach|var|backtest|attribut/i.test(text);

    setIsAgentRunning(true);
    setIsAssistantTyping(true);
    await sleep(500);

    // open middle panel automatically on agent activity? leave to user; but pulse on tabs draws attention.

    // Generate simulated tool steps
    const steps = [];
    steps.push({ kind: 'skill', name: 'Skill', arg: 'risk_warehouse.search', res: 'pulled 3 datasets' });
    steps.push({ kind: 'read', name: 'Read', arg: pickFile(text) });
    if (/sql|query|warehouse/i.test(text) || Math.random() > 0.5) {
      steps.push({ kind: 'subagent', name: 'SQL Analyst', arg: 'select … from positions where …', res: `${(Math.random()*4000|0)+200} rows` });
    }
    if (/stress|breach|backtest|attribut/i.test(text) || Math.random() > 0.6) {
      const bashCmd = wantsDashboard ? `python -m riskmind.analyze --topic "${text.slice(0, 32).replace(/"/g, '')}"` : `python -m riskmind.query --q "${text.slice(0,40)}"`;
      steps.push({ kind: 'bash', cmd: bashCmd, out: [
        { t: 'out', s: '[riskmind] connecting to risk warehouse…' },
        { t: 'out', s: '[riskmind] running analysis…' },
        { t: 'out', s: '[riskmind] aggregating attribution buckets' },
        { t: 'out', s: 'done in ' + (1.4 + Math.random()*3).toFixed(2) + 's' },
      ] });
    }
    if (wantsDashboard) {
      steps.push({ kind: 'subagent', name: 'Data Visualizer', arg: `render dashboard`, res: 'artifact ready' });
    }

    // stream tool log
    for (const t of steps) {
      await sleep(420 + Math.random() * 240);
      if (t.kind === 'bash') {
        const entry = { kind: 'bash', cmd: t.cmd, ts: ts(), label: 'subprocess', lines: [] };
        setAgentLog(l => [...l, entry]);
        for (const ln of t.out) {
          await sleep(160 + Math.random() * 140);
          setAgentLog(l => {
            const copy = l.slice();
            const last = copy[copy.length - 1];
            if (last && last.kind === 'bash') copy[copy.length - 1] = { ...last, lines: [...last.lines, ln] };
            return copy;
          });
        }
      } else {
        setAgentLog(l => [...l, { ...t, ts: ts() }]);
      }
    }

    // Build the assistant response text
    const topic = deriveTopic(text);
    const responseText = wantsDashboard
      ? `I've pulled the relevant snapshots, run the attribution, and assembled a new dashboard — **${topic}**. The headline metrics, P&L walk, and contributor table are all live. Open the **JSON** tab in the middle panel to edit the spec and hit Render to update.`
      : `Here's what I found for **${topic}**. Want me to expand this into a full dashboard with the standard contributor breakdown and stress walk?`;

    // pre-create artifact placeholder (generating)
    let newArtId = null;
    if (wantsDashboard) {
      newArtId = 'a_' + Math.random().toString(36).slice(2, 8);
      const placeholder = { id: newArtId, name: topic + '.html', spec: null, generating: true };
      setArtifacts(a => [...a, placeholder]);
      setActiveArtifactId(newArtId);
    }

    // assistant message
    setChat(c => ({ ...c, messages: [...c.messages, { role: 'assistant', content: responseText, streamed: streaming ? '' : responseText, tools: steps, artifact: wantsDashboard ? { id: newArtId, name: topic + '.html' } : null }] }));

    if (streaming) {
      const full = responseText;
      for (let i = 1; i <= full.length; i += 5 + Math.floor(Math.random()*4)) {
        const sub = full.slice(0, i);
        setChat(c => { const ms = c.messages.slice(); ms[ms.length - 1] = { ...ms[ms.length - 1], streamed: sub }; return { ...c, messages: ms }; });
        await sleep(20);
      }
      setChat(c => { const ms = c.messages.slice(); ms[ms.length - 1] = { ...ms[ms.length - 1], streamed: responseText }; return { ...c, messages: ms }; });
    }

    // fill the artifact spec
    if (newArtId) {
      await sleep(220);
      const spec = window.NEW_DASHBOARD_TEMPLATE(topic);
      setArtifacts(a => a.map(x => x.id === newArtId ? { ...x, spec, generating: false } : x));
    }

    setIsAgentRunning(false);
    setIsAssistantTyping(false);
  };

  // open-artifact event from chat
  useEffect(() => {
    const h = (e) => setActiveArtifactId(e.detail);
    window.addEventListener('riskmind:open-artifact', h);
    return () => window.removeEventListener('riskmind:open-artifact', h);
  }, []);

  const closeArtifact = (id) => {
    setArtifacts(a => {
      const next = a.filter(x => x.id !== id);
      if (id === activeArtifactId) {
        setActiveArtifactId(next[0]?.id || null);
      }
      return next;
    });
  };

  const activeArtifact = artifacts.find(a => a.id === activeArtifactId);

  return (
    <div className="app">
      <NavRail
        leftMode={leftMode}
        setLeftMode={setLeftMode}
        isAgentRunning={isAgentRunning}
        theme={theme}
        onToggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')}
      />
      <div className="panel" style={{ width: leftWidth, flexShrink: 0 }}>
        <LeftPanel
          mode={leftMode}
          onToggleMiddle={() => setMiddleOpen(o => !o)}
          middleOpen={middleOpen}
          chat={chat}
          onSendMessage={onSendMessage}
          isAssistantTyping={isAssistantTyping}
          onLoadHistory={(id) => {
            const h = window.HISTORY.find(x => x.id === id);
            if (!h) return;
            // load preloaded chat for h1, otherwise create a fresh placeholder using the preview
            if (id === 'h1') {
              setChat({ id, title: h.title, messages: [] });
              setAgentLog([]);
              setLeftMode('chat');
              setTimeout(() => playScript(window.PRELOADED_CHAT), 80);
            } else {
              setChat({
                id, title: h.title, messages: [
                  { role: 'user', content: h.preview },
                  { role: 'assistant', content: `Loaded "${h.title}" from your history. Pick up where we left off — or ask a new follow-up.`, streamed: `Loaded "${h.title}" from your history. Pick up where we left off — or ask a new follow-up.`, tools: [
                    { kind: 'skill', name: 'Skill', arg: 'history.restore --id ' + id },
                  ] },
                ],
              });
              setAgentLog([
                { kind: 'skill', name: 'Skill', arg: 'history.restore --id ' + id, ts: nowTs() },
              ]);
              setLeftMode('chat');
            }
          }}
          activeHistoryId={chat.id}
          onNewChat={() => { setChat({ id: 'new_' + Date.now(), title: 'New chat', messages: [] }); setAgentLog([]); }}
          theme={theme}
          onToggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')}
        />
        <div className="resize-handle" onMouseDown={startResize('left')}></div>
      </div>
      {middleOpen ? (
        <div className="panel" style={{ width: middleWidth, flexShrink: 0 }}>
          <MiddlePanel
            tab={middleTab}
            setTab={setMiddleTab}
            plugins={plugins}
            togglePlugin={togglePlugin}
            agentLog={agentLog}
            isAgentRunning={isAgentRunning}
            jsonText={jsonText}
            setJsonText={setJsonText}
            jsonDirty={jsonDirty}
            jsonError={jsonError}
            onRender={handleRender}
            activeArtifactName={activeArtifact?.name}
            artifacts={artifacts}
            activeArtifactId={activeArtifactId}
            setActiveArtifactId={setActiveArtifactId}
            activeArtifactType={activeArtifact?.type}
          />
          <div className="resize-handle" onMouseDown={startResize('middle')}></div>
        </div>
      ) : null}
      <div className="panel" style={{ flex: 1, minWidth: 0 }}>
        <RightPanel
          artifacts={artifacts}
          activeArtifactId={activeArtifactId}
          setActiveArtifactId={setActiveArtifactId}
          closeArtifact={closeArtifact}
          onMiddleOpen={() => { setMiddleOpen(true); setMiddleTab('editor'); }}
          middleOpen={middleOpen}
          onNewArtifact={onNewArtifact}
          onRerender={() => setArtifacts(a => a.map(x => x.id === activeArtifactId ? { ...x, renderKey: (x.renderKey || 0) + 1 } : x))}
        />
      </div>


    </div>
  );
}

const NavRail = ({ leftMode, setLeftMode, isAgentRunning, theme, onToggleTheme }) => (
  <div className="nav-rail">
    <div className="logo">R</div>
    <button className={`nav-btn ${leftMode === 'chat' ? 'active' : ''}`} title="Chat" onClick={() => setLeftMode('chat')}>
      <Icon name="chat" size={18}/>
      {isAgentRunning ? <span className="dot"></span> : null}
    </button>
    <button className={`nav-btn ${leftMode === 'history' ? 'active' : ''}`} title="History" onClick={() => setLeftMode('history')}>
      <Icon name="history" size={18}/>
    </button>
    <button className={`nav-btn ${leftMode === 'files' ? 'active' : ''}`} title="Files" onClick={() => setLeftMode('files')}>
      <Icon name="file" size={18}/>
    </button>
    <div className="spacer"></div>
    <button className="nav-btn" title={theme === 'dark' ? 'Light mode' : 'Dark mode'} onClick={onToggleTheme}>
      <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={18}/>
    </button>
    <button className="nav-btn" title="Settings">
      <Icon name="settings" size={18}/>
    </button>
  </div>
);

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const pickFile = (text) => {
  const files = window.FILES.map(f => f.name);
  if (/jpy|rates/i.test(text)) return 'eod_positions_2026-05-10.parquet';
  if (/fx|vol/i.test(text)) return 'fx_vol_surface_jpy.csv';
  if (/ccar/i.test(text)) return 'CCAR_IMS_scenarios_Q1.xlsx';
  if (/p&?l|pnl/i.test(text)) return 'desk_pnl_journal_2026-05-10.json';
  if (/limit/i.test(text)) return 'limits_master.yml';
  return files[Math.floor(Math.random() * files.length)];
};

const deriveTopic = (text) => {
  if (text.startsWith('/')) {
    const map = {
      '/stress-pnl': 'Stress P&L Explain',
      '/var-breach': 'VaR Breach Investigation',
      '/ccar-status': 'CCAR Submission Readiness',
      '/limit-util': 'Limit Utilization Snapshot',
      '/backtest': 'VaR Backtest Exceptions',
    };
    const k = text.split(' ')[0];
    return map[k] || k.slice(1).replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }
  // truncate to a title
  const t = text.replace(/[?.!]+$/, '').trim();
  return t.length > 56 ? t.slice(0, 56) + '…' : t.slice(0, 1).toUpperCase() + t.slice(1);
};

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
