// Dashboard renderer — pure presentational. Reads a JSON spec.
const fmtNum = (n) => typeof n === 'number' ? n.toLocaleString(undefined, { maximumFractionDigits: 2 }) : n;

const Sparkbars = ({ bins, var99, es99 }) => {
  const w = 520, h = 140, pad = 28;
  const max = Math.max(...bins);
  const bw = (w - pad * 2) / bins.length;
  const breach = Math.floor(bins.length * 0.12);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%', height: 'auto' }}>
      <line x1={pad} y1={h-pad} x2={w-pad} y2={h-pad} stroke="var(--border)" />
      {bins.map((b, i) => {
        const bh = (b / max) * (h - pad * 2);
        const x = pad + i * bw + 2;
        const y = h - pad - bh;
        const isTail = i < breach;
        return <rect key={i} x={x} y={y} width={bw-4} height={bh} rx="2" fill={isTail ? 'var(--error)' : 'var(--accent)'} opacity={isTail ? 0.85 : 0.7}/>;
      })}
      <line x1={pad + breach * bw} y1={pad} x2={pad + breach * bw} y2={h-pad} stroke="var(--error)" strokeDasharray="3 3"/>
      <text x={pad + breach * bw + 4} y={pad + 10} fill="var(--error)" fontSize="10" fontFamily="Geist Mono">VaR99 {var99}</text>
      <text x={pad + breach * bw + 4} y={pad + 24} fill="var(--text-3)" fontSize="10" fontFamily="Geist Mono">ES99 {es99}</text>
    </svg>
  );
};

const Waterfall = ({ series }) => {
  const w = 560, h = 200, pad = 32;
  // compute running totals
  let running = 0;
  const vals = series.map((s, i) => {
    if (s.kind === 'base') { running = s.value; return { ...s, from: 0, to: s.value }; }
    const from = running, to = running + s.value;
    running = to;
    return { ...s, from, to };
  });
  const allY = vals.flatMap(v => [v.from, v.to]);
  const minV = Math.min(0, ...allY);
  const maxV = Math.max(...allY) * 1.1;
  const y = v => h - pad - ((v - minV) / (maxV - minV)) * (h - pad * 2);
  const bw = (w - pad * 2) / vals.length;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%', height: 'auto' }}>
      <line x1={pad} y1={h-pad} x2={w-pad} y2={h-pad} stroke="var(--border)" />
      {vals.map((v, i) => {
        const x = pad + i * bw + 6;
        const top = y(Math.max(v.from, v.to));
        const bot = y(Math.min(v.from, v.to));
        const fill = v.kind === 'base' ? 'var(--text-2)' : v.kind === 'pos' ? 'var(--error)' : 'var(--success)';
        return (
          <g key={i}>
            <rect x={x} y={top} width={bw - 12} height={Math.max(2, bot - top)} fill={fill} opacity="0.85" rx="2"/>
            {i < vals.length - 1 ? <line x1={x + bw - 12} y1={y(v.to)} x2={x + bw + 6} y2={y(v.to)} stroke="var(--border-strong)" strokeDasharray="2 2"/> : null}
            <text x={x + (bw - 12)/2} y={top - 4} textAnchor="middle" fontSize="10" fill="var(--text)" fontFamily="Geist Mono">{v.kind === 'base' ? v.value : (v.value > 0 ? '+' : '') + v.value}</text>
            <text x={x + (bw - 12)/2} y={h - pad + 14} textAnchor="middle" fontSize="10" fill="var(--text-3)">{v.label}</text>
          </g>
        );
      })}
    </svg>
  );
};

const renderInsight = (ins) => {
  // very small markdown: **bold**
  const html = (ins.body || '').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  return (
    <div className="insight" key={ins.label}>
      <div className="ic">AI</div>
      <div className="body">
        <div className="lbl">{ins.label}</div>
        <p dangerouslySetInnerHTML={{ __html: html }}></p>
      </div>
    </div>
  );
};

const Dashboard = ({ spec }) => {
  if (!spec || typeof spec !== 'object') {
    return <div className="empty"><div className="big"><Icon name="alert" size={22}/></div><div className="t">Invalid dashboard JSON</div><div className="s">Check the editor for syntax errors and hit Render.</div></div>;
  }
  const ins = (anchor) => (spec.insights || []).filter(i => i.anchor === anchor);
  return (
    <div className="dashboard">
      <div className="db-head">
        <div>
          <h1>{spec.title}</h1>
          <div className="sub">{spec.subtitle}</div>
        </div>
        <div className="meta-pills">
          {spec.status ? <span className={`pill ${spec.status.tone === 'warn' ? 'warn' : ''}`}><span className="d"></span>{spec.status.label}</span> : null}
          {(spec.meta || []).map(m => <span className="pill" key={m.label}><span style={{ color: 'var(--text-3)' }}>{m.label}</span>&nbsp;{m.value}</span>)}
        </div>
      </div>

      <div className="db-section-title">Headline metrics</div>
      <div className="kpis">
        {(spec.kpis || []).map((k, i) => (
          <div className="kpi" key={i}>
            <div className="l">{k.label}</div>
            <div className="v">{k.value}</div>
            <div className={`d ${k.dir === 'up' ? 'up' : k.dir === 'dn' ? 'dn' : ''}`}>
              {k.dir === 'up' ? '▲' : k.dir === 'dn' ? '▼' : '•'} {k.delta}
              {k.sub ? <span style={{ marginLeft: 6, color: 'var(--text-3)' }}>· {k.sub}</span> : null}
            </div>
          </div>
        ))}
      </div>

      {ins('after-kpis').map(renderInsight)}

      <div className="db-section-title">P&L attribution</div>
      <div className="grid-2">
        <div className="chart-card">
          <div className="ch">
            <div>
              <h3>{spec.walk?.title}</h3>
              <div className="sub">{spec.walk?.sub}</div>
            </div>
            <div className="legend">
              <span><span className="sw" style={{ background: 'var(--text-2)' }}></span>Base</span>
              <span><span className="sw" style={{ background: 'var(--error)' }}></span>Loss</span>
              <span><span className="sw" style={{ background: 'var(--success)' }}></span>Gain</span>
            </div>
          </div>
          {spec.walk ? <Waterfall series={spec.walk.series}/> : null}
        </div>
        <div className="chart-card">
          <div className="ch">
            <div>
              <h3>{spec.histo?.title}</h3>
              <div className="sub">{spec.histo?.sub}</div>
            </div>
            <div className="legend">
              <span><span className="sw" style={{ background: 'var(--accent)', opacity: 0.7 }}></span>P&L</span>
              <span><span className="sw" style={{ background: 'var(--error)' }}></span>Tail</span>
            </div>
          </div>
          {spec.histo ? <Sparkbars bins={spec.histo.bins} var99={spec.histo.var99} es99={spec.histo.es99}/> : null}
        </div>
      </div>

      {ins('after-walk').map(renderInsight)}

      <div className="db-section-title">Top contributors</div>
      <div className="chart-card">
        <div className="ch">
          <div>
            <h3>{spec.contributors?.title}</h3>
            <div className="sub">{spec.contributors?.sub}</div>
          </div>
        </div>
        <table className="table">
          <thead><tr><th>Risk factor</th><th style={{ width: '20%' }}>Marginal</th><th style={{ width: '35%' }}>Share</th><th className="num">% of breach</th></tr></thead>
          <tbody>
            {(spec.contributors?.rows || []).map((r, i) => {
              const w = Math.min(100, Math.max(2, Math.abs(r.pct)));
              return (
                <tr key={i}>
                  <td>{r.factor}</td>
                  <td className={r.value >= 0 ? 'num pos' : 'num neg'}>{r.value >= 0 ? '+' : ''}{fmtNum(r.value)}</td>
                  <td><div className="bar"><span style={{ width: w + '%', background: r.value >= 0 ? 'var(--accent)' : 'var(--success)' }}></span></div></td>
                  <td className="num">{r.pct}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {ins('after-table').map(renderInsight)}
    </div>
  );
};

window.Dashboard = Dashboard;
