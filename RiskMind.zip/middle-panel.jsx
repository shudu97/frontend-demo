// Middle panel: Agent status (plugins + tool log) / JSON editor

const MiddlePanel = ({ tab, setTab, plugins, togglePlugin, agentLog, isAgentRunning, jsonText, setJsonText, jsonDirty, jsonError, onRender, activeArtifactName, artifacts, activeArtifactId, setActiveArtifactId, activeArtifactType }) => {
  return (
    <>
      <div className="middle-tabs">
        <button className={`middle-tab ${tab === 'agent' ? 'active' : ''}`} onClick={() => setTab('agent')}>
          {isAgentRunning ? <span className="pulse"></span> : <Icon name="settings" size={13}/>}
          Agent
        </button>
        <button className={`middle-tab ${tab === 'editor' ? 'active' : ''}`} onClick={() => setTab('editor')}>
          <Icon name="code" size={13}/>
          Artifact JSON
          {jsonDirty ? <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--warning)', marginLeft: 4 }}></span> : null}
        </button>
        <div style={{ flex: 1 }}></div>
        <div style={{ display: 'flex', alignItems: 'center', paddingRight: 8, fontSize: 11, color: 'var(--text-3)', fontFamily: 'Geist Mono, monospace' }}>
          {isAgentRunning ? 'agent · running' : 'agent · idle'}
        </div>
      </div>
      {tab === 'agent' ? (
        <AgentView plugins={plugins} togglePlugin={togglePlugin} log={agentLog} isRunning={isAgentRunning}/>
      ) : (
        <JsonEditor
          jsonText={jsonText}
          setJsonText={setJsonText}
          jsonDirty={jsonDirty}
          jsonError={jsonError}
          onRender={onRender}
          activeArtifactName={activeArtifactName}
          artifacts={artifacts}
          activeArtifactId={activeArtifactId}
          setActiveArtifactId={setActiveArtifactId}
          activeArtifactType={activeArtifactType}
        />
      )}
    </>
  );
};

const AgentView = ({ plugins, togglePlugin, log, isRunning }) => {
  const business = plugins.filter(p => p.kind === 'business');
  const special = plugins.filter(p => p.kind === 'special');
  const connectedCount = (arr) => arr.filter(p => p.status === 'connected').length;

  const logRef = React.useRef(null);
  React.useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [log.length, isRunning]);

  return (
    <>
      <div className="plugins-section">
        <div className="plugin-kind-label">
          <span className="l">Business plugins</span>
          <span className="c">{connectedCount(business)}/{business.length} connected</span>
        </div>
        <div className="plugins-grid">
          {business.map(p => (
            <button key={p.id} className={`plugin-badge ${p.status}`} onClick={() => togglePlugin(p.id)} title={p.desc}>
              <span className="light"></span>
              <span className="name">{p.name}</span>
            </button>
          ))}
        </div>
        <div className="plugin-kind-label">
          <span className="l">Subagents</span>
          <span className="c">{connectedCount(special)}/{special.length} connected</span>
        </div>
        <div className="plugins-grid">
          {special.map(p => (
            <button key={p.id} className={`plugin-badge ${p.status}`} onClick={() => togglePlugin(p.id)} title={p.desc}>
              <span className="light"></span>
              <span className="name">{p.name}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="tool-log" ref={logRef}>
        {log.length === 0 ? (
          <div className="empty" style={{ flex: 1 }}>
            <div className="big"><Icon name="terminal" size={22}/></div>
            <div className="t">Agent idle</div>
            <div className="s">When you send a message, tool calls and bash output will stream here in real time.</div>
          </div>
        ) : log.map((e, i) => <LogRow key={i} entry={e}/>)}
        {isRunning ? (
          <div className="log-row" style={{ color: 'var(--text-3)' }}>
            <span className="ts">{nowTs()}</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <span className="caret" style={{ background: 'var(--text-3)', height: 11, width: 6 }}></span>
              <span style={{ fontFamily: 'Geist Mono, monospace' }}>agent thinking…</span>
            </span>
          </div>
        ) : null}
      </div>
    </>
  );
};

const nowTs = () => {
  const d = new Date();
  return d.toTimeString().slice(0, 8);
};

const LogRow = ({ entry }) => {
  if (entry.kind === 'bash') {
    return (
      <div className="bash-block">
        <div className="bash-head">
          <Icon name="terminal" size={11}/>
          <span style={{ flex: 1 }}>bash · {entry.label || 'shell'}</span>
          <span style={{ color: 'var(--text-3)' }}>{entry.ts || ''}</span>
        </div>
        <div className="bash-body">
          <div><span className="prompt">$</span> <span className="out">{entry.cmd}</span></div>
          {(entry.lines || []).map((l, i) => (
            <div key={i} className={l.t === 'err' ? 'err' : 'out'}>{l.s}</div>
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className={`log-row ${entry.kind}`}>
      <span className="body">
        <span className="name">{entry.name}</span>{entry.arg ? <> <span className="arg">{entry.arg}</span></> : null}
      </span>
    </div>
  );
};

// JSON syntax highlighter
const escapeHTML = (s) => s.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const highlightJson = (src) => {
  // tokenize lightly: strings, keys, numbers, booleans, null, punctuation
  const safe = escapeHTML(src);
  // strings (and keys)
  let out = safe.replace(/(&quot;(?:\\.|[^&\\])*?&quot;)(\s*:)?/g, (m, str, colon) => {
    if (colon) return `<span class="json-key">${str}</span><span class="json-punct">${colon}</span>`;
    return `<span class="json-string">${str}</span>`;
  });
  out = out.replace(/\b(true|false)\b/g, '<span class="json-bool">$1</span>');
  out = out.replace(/\bnull\b/g, '<span class="json-null">null</span>');
  out = out.replace(/(-?\d+\.?\d*(?:[eE][+-]?\d+)?)/g, (m) => `<span class="json-number">${m}</span>`);
  out = out.replace(/([{}\[\],])/g, '<span class="json-punct">$1</span>');
  return out;
};

const JsonEditor = ({ jsonText, setJsonText, jsonDirty, jsonError, onRender, activeArtifactName, artifacts, activeArtifactId, setActiveArtifactId }) => {
  const taRef = React.useRef(null);
  const preRef = React.useRef(null);

  const sync = () => {
    const ta = taRef.current; const pre = preRef.current;
    if (!ta || !pre) return;
    pre.style.transform = `translate(${-ta.scrollLeft}px, ${-ta.scrollTop}px)`;
  };

  React.useEffect(() => { sync(); }, [jsonText]);

  const lines = jsonText.split('\n');

  return (
    <div className="json-editor-wrap">
      <div className="json-toolbar">
        <div className="file-pick">
          <Icon name="doc" size={13}/>
          <select value={activeArtifactId || ''} onChange={e => setActiveArtifactId(e.target.value)}>
            {artifacts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>
        <button className="btn-ghost" onClick={() => { try { const parsed = JSON.parse(jsonText); setJsonText(JSON.stringify(parsed, null, 2)); } catch(e) {} }} title="Format JSON">Format</button>
        <button className="btn-primary" onClick={onRender} disabled={!!jsonError}>
          <Icon name="play" size={11}/>
          Render
        </button>
      </div>
      <div className="json-editor">
        <div className="json-gutter">
          {lines.map((_, i) => <div key={i}>{i+1}</div>)}
        </div>
        <div className="json-content">
          <pre ref={preRef} dangerouslySetInnerHTML={{ __html: highlightJson(jsonText) + '\n' }}></pre>
          <textarea
            ref={taRef}
            value={jsonText}
            spellCheck={false}
            onChange={e => setJsonText(e.target.value)}
            onScroll={sync}
            onKeyDown={(e) => {
              if (e.key === 'Tab') {
                e.preventDefault();
                const ta = e.target;
                const s = ta.selectionStart, en = ta.selectionEnd;
                const v = ta.value;
                setJsonText(v.slice(0, s) + '  ' + v.slice(en));
                requestAnimationFrame(() => { ta.selectionStart = ta.selectionEnd = s + 2; });
              }
              if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                e.preventDefault();
                if (!jsonError) onRender();
              }
            }}
          />
        </div>
      </div>
      <div className={`json-status ${jsonError ? 'err' : 'ok'}`}>
        {jsonError ? (
          <><Icon name="alert" size={11}/> <span>{jsonError}</span></>
        ) : (
          <><Icon name="check" size={11}/> <span>Valid JSON · {jsonText.length.toLocaleString()} chars · {lines.length} lines</span></>
        )}
        <div style={{ flex: 1 }}></div>
        {jsonDirty ? <span className="dirty">unsaved</span> : null}
        <span style={{ color: 'var(--text-3)' }}>⌘+Enter to render</span>
      </div>
    </div>
  );
};

window.MiddlePanel = MiddlePanel;
