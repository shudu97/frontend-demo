// Right panel: artifact tabs + content

const RightPanel = ({ artifacts, activeArtifactId, setActiveArtifactId, closeArtifact, onMiddleOpen, middleOpen, onNewArtifact, onRerender }) => {
  const active = artifacts.find(a => a.id === activeArtifactId);
  return (
    <>
      <div className="right-tabs">
        {artifacts.length === 0 ? (
          <div style={{ padding: '0 12px', display: 'flex', alignItems: 'center', height: '100%', color: 'var(--text-3)', fontSize: 12 }}>No artifacts</div>
        ) : artifacts.map(a => (
          <div key={a.id} className={`right-tab ${a.id === activeArtifactId ? 'active' : ''} ${a.generating ? 'generating' : ''}`} onClick={() => setActiveArtifactId(a.id)}>
            <span className="file-dot"></span>
            <span className="tab-name">{a.name}</span>
            <button className="close" onClick={(e) => { e.stopPropagation(); closeArtifact(a.id); }}><Icon name="x" size={11}/></button>
          </div>
        ))}
        <button className="icon-btn" title="New HTML artifact" onClick={onNewArtifact} style={{ margin: '0 4px' }}><Icon name="plus" size={14}/></button>
        <div style={{ flex: 1, borderBottom: '1px solid var(--border)', alignSelf: 'stretch' }}></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '0 8px', borderBottom: '1px solid var(--border)', alignSelf: 'stretch' }}>
          <button type="button" className="icon-btn" title="Edit in JSON/HTML editor" onClick={(e) => { e.preventDefault(); e.stopPropagation(); onMiddleOpen && onMiddleOpen(); }}><Icon name="code" size={14}/></button>
          <button type="button" className="icon-btn" title="Re-render" onClick={(e) => { e.preventDefault(); e.stopPropagation(); onRerender && onRerender(); }}><Icon name="refresh" size={14}/></button>
          <button className="icon-btn" title="More"><Icon name="menu-dots" size={14}/></button>
        </div>
      </div>
      <div className="right-content">
        {active ? (
          active.generating ? (
            <div className="empty">
              <div className="big"><span className="caret" style={{ background: 'var(--accent)' }}></span></div>
              <div className="t">{active.name}</div>
              <div className="s">Agent is generating this artifact — see the Agent tab in the middle panel for live progress.</div>
            </div>
          ) : active.type === 'html' ? (
            <iframe key={active.id + '-' + (active.renderKey || 0)} srcDoc={active.html || ''} style={{ width: '100%', height: '100%', border: 'none', background: '#fff' }} sandbox="allow-scripts allow-same-origin" title={active.name}/>
          ) : (
            <Dashboard spec={active.spec}/>
          )
        ) : (
          <div className="empty">
            <div className="big"><Icon name="spark" size={22}/></div>
            <div className="t">No artifact open</div>
            <div className="s">Ask RiskMind a question — it'll build dashboards, reports and interactive analyses here.</div>
          </div>
        )}
      </div>
    </>
  );
};

window.RightPanel = RightPanel;
